﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WMPLib;
namespace awsome
{
    public partial class Form1 : Form
    {
        // varialbel entities
        // stars-----------
        PictureBox[] stars;
        int backgroundspeed;
        Random rnd;
        // end -------------
        // playerspee---------
        int playerspeed;
       // end ----------------
        
        // munition-----------

        PictureBox[] munitions;
        int munitionspeed;
        // end munition ---------

        //meda -------------
        WindowsMediaPlayer gamMedia;

        WindowsMediaPlayer shootgMedia;

        WindowsMediaPlayer explosion;

        //end sound -----------------------

        //Enemies-------------------------

        PictureBox[] enemies;

        int enemiespeed;
        //---------end---------------

        // start enemies munition -------

        PictureBox[] EnemiesMuntions;
        int EnemiesMunitionspeed;
       // enemies muniton end -----------




        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

// star load --------------------------------------------------------------------------------------------------------
            backgroundspeed = 4;
            stars = new PictureBox[15];
            rnd = new Random();

            for (int i = 0; i < stars.Length;i++ )
            {
                stars[i] = new PictureBox();
                stars[i].BorderStyle = BorderStyle.None;
                stars[i].Location = new Point(rnd.Next(20,580),rnd.Next(-10,400));
                if(i % 2 == 1)
                {
                    stars[i].Size = new Size(2,2);
                    stars[i].BackColor = Color.Wheat;
                }
                else
                {

                    stars[i].Size = new Size(3, 3);
                    stars[i].BackColor = Color.DarkGray;
                }

                this.Controls.Add(stars[i]);
            }
// end star load ---------------------------------------------------------------------------------------------------------------

// player load method ----------------------------------------------------------------------------------------------------------------------

            playerspeed = 4;

//-------- end load method ----------------------------------------------------------------------------------------------------------------------

// munition load method ----------------------------------------------------------------------------------------------------------------------


            munitionspeed = 20;
            
            munitions = new PictureBox[3];

            // load munition image ===

            Image munition = Image.FromFile(@"asset\\power.png");

            for (int i = 0; i < munitions.Length;i++ )
            {
                munitions[i] = new PictureBox();

                munitions[i].Size = new Size(8,8);

                munitions[i].Image = munition;

                munitions[i].BorderStyle = BorderStyle.None;

                munitions[i].SizeMode = PictureBoxSizeMode.Zoom;

                this.Controls.Add(munitions[i]);

            }

// munition load method  End ----------------------------------------------------------------------------------------------------------------------


//Gamew sound method ----------------------------------------------------------------------------------------------------------------------


            gamMedia = new WindowsMediaPlayer();

            shootgMedia = new WindowsMediaPlayer();

            explosion = new WindowsMediaPlayer();

            explosion.URL = "sony\\kill.mp3";

            gamMedia.URL = "song\\mas.mp3";

            shootgMedia.URL = "song\\shot.mp3";

            gamMedia.settings.setMode("loop",true);

            gamMedia.settings.volume = 50000;

            shootgMedia.settings.volume = 18;
            explosion.settings.volume = 10;


            gamMedia.controls.play();

 // End Sound --------------------------------------------------------------------------------------------------------------------------      
        
 // enemies load method ---------------------------------------------------------------------------------------------------------------

            enemiespeed = 4;

            Image enemie1 = Image.FromFile(@"asset\\eni1.png");
            Image enemie2 = Image.FromFile(@"asset\\eni2.png");
            Image enemie3 = Image.FromFile(@"asset\\asq.png");
            Image boss1 = Image.FromFile(@"asset\\cross.png");
            Image boss2 = Image.FromFile(@"asset\\boss4.png");

            enemies = new PictureBox[10];


            for (int i = 0; i < enemies.Length; i++)
            {
                enemies[i] = new PictureBox();
                enemies[i].Size = new Size(40,40);

                enemies[i].SizeMode = PictureBoxSizeMode.Zoom;
                enemies[i].BorderStyle = BorderStyle.None;

                enemies[i].Visible = false;
                this.Controls.Add(enemies[i]);
                enemies[i].Location = new Point((i + 1)* 50 ,-50);
            }

            enemies[0].Image = boss1;
            enemies[1].Image = enemie1;
            enemies[2].Image = enemie2;
            enemies[3].Image = enemie3;
            enemies[4].Image = enemie1;
            enemies[5].Image = enemie2;
            enemies[6].Image = enemie3;
            enemies[7].Image = enemie1;
            enemies[8].Image = enemie2;
            enemies[0].Image = boss2;
// Enemies muniton -----------------------------------------------------------------------------------------------------------------

            EnemiesMunitionspeed = 4;
            
            EnemiesMuntions = new PictureBox[10];

            for (int i = 0; i < EnemiesMuntions.Length;i++ )
            {
                EnemiesMuntions[i] = new PictureBox();
                EnemiesMuntions[i].Size = new Size(2,25);
                EnemiesMuntions[i].Visible = false;
                EnemiesMuntions[i].BackColor = Color.Yellow;
                int x = rnd.Next(0,10);
                EnemiesMuntions[i].Location = new Point(EnemiesMuntions[x].Location.X, EnemiesMuntions[x].Location.Y - 20);

                this.Controls.Add(EnemiesMuntions[i]);
            }







        
        
        
        
        }

    
// stars timer methods ------------------------------------------------------------------------------------------------------------        
        private void Movebgtimer_Tick(object sender, EventArgs e)
        {
            for(int i = 0; i < stars.Length/2; i++)
            {
                stars[i].Top += backgroundspeed;
                if( stars[i].Top>=this.Height )
                {
                    stars[i].Top = -stars[i].Height;
                }
    
           }


            for (int i = stars.Length / 2; i < stars.Length;i++ )
            {
                stars[i].Top += backgroundspeed - 2;

                if(stars[i].Top >= this.Height)
                {
                    stars[i].Top = -stars[i].Height;
                }
            }
        }

// stars method timer end --------------------------------------------------------------------------------------------------------


// player method timer end --------------------------------------------------------------------------------------------------------
      
        
        private void LeftMoveTimer_Tick(object sender, EventArgs e)
        {
            if(player.Left > 10)
            {
                player.Left -= playerspeed;
            }
        }

        private void RightMoveTimer_Tick(object sender, EventArgs e)
        {
            if(player.Right < 580)
            {
                player.Left += playerspeed;
            }
        }

        private void DownMoveTimer_Tick(object sender, EventArgs e)
        {
            if(player.Top < 400)
            {
                player.Top += playerspeed;
            }
        }

        private void UpMoveTimer_Tick(object sender, EventArgs e)
        {
            if(player.Top > 10)
            {
                player.Top -= playerspeed;
            }
        }

        private void Form1_KeyDown(object sender, KeyEventArgs e)
        {
            if(e.KeyCode == Keys.Right)
            {
                RightMoveTimer.Start();
            }

            if(e.KeyCode == Keys.Left)
            {
                LeftMoveTimer.Start();
            }

            if(e.KeyCode == Keys.Down)
            {
                DownMoveTimer.Start();
            }

            if(e.KeyCode == Keys.Up)
            {
                UpMoveTimer.Start();
            }
        }

        private void Form1_KeyUp(object sender, KeyEventArgs e)
        {
            RightMoveTimer.Stop();
            LeftMoveTimer.Stop();
            DownMoveTimer.Stop();
            UpMoveTimer.Stop();
        }

// player timer method end ---------------------------------------------------------------------------------------------------


// Move munition Timer Start ------------------------------------------------------------------------------------------------
        
        
        
        private void MoveMunitionTimer_Tick(object sender, EventArgs e)
        {
            shootgMedia.controls.play();

            for (int i = 0; i < munitions.Length; i++ )
            {
                if (munitions[i].Top > 0)
                {
                    munitions[i].Visible = true;
                    munitions[i].Top -= munitionspeed;

                    collision();
                }
  
                else
                {
                    munitions[i].Visible = false;
                    munitions[i].Location = new Point(player.Location.X + 20 ,player.Location.Y -i * 30);
                }
            }
        }


// munition End -----------------------------------------------------------------------------------------------------------        


// enemie start -----------------------------------------------------------------------------------------------------------        
         
        private void MoveEnemiestimer_Tick(object sender, EventArgs e)
        {

            MoveEnemie(enemies,enemiespeed);

        }

        private void MoveEnemie(PictureBox[] array,int speed)
        {

            for (int i = 0; i < array.Length;i++ )
            {
                array[i].Visible = true;
                array[i].Top += speed;

                if(array[i].Top > this.Height)
                {
                    array[i].Location = new Point((i + 1) * 50, -200);
                }
            }

        }


        private void collision()
        {

            for (int i = 0; i < enemies.Length; i++ )
            {
                if (munitions[0].Bounds.IntersectsWith(enemies[i].Bounds)
                    || munitions[1].Bounds.IntersectsWith(enemies[i].Bounds) || munitions[2].Bounds.IntersectsWith(enemies[i].Bounds)) 
                {
                    explosion.controls.play();
                    enemies[i].Location = new Point((i + 1) *50,-100);
                }
                if(player.Bounds.IntersectsWith(enemies[i].Bounds))
                {
                    explosion.settings.volume = 100;
                    explosion.controls.play();
                    player.Visible = false;
                    GameOver("");
                }
            }
      }
         
        private void GameOver(String str)
        {
            gamMedia.controls.stop();
            StopTimer();
        }
        private void StopTimer()
        {
            Movebgtimer.Stop();
            MoveEnemiestimer.Stop();
            MoveMunitionTimer.Stop();
        }
        private void StartTimer()
        {
            Movebgtimer.Start();
            MoveEnemiestimer.Start();
            MoveMunitionTimer.Start();
        }


// enemie End -----------------------------------------------------------------------------------------------------------  
        private void EnemiesmunitionTimer_Tick(object sender, EventArgs e)
        {

            for (int i = 0; i < EnemiesMuntions.Length;i++ )
            {
                try { 
                if (EnemiesMuntions[i].Top < this.Height)
                {
                    EnemiesMuntions[i].Visible = true;
                    EnemiesMuntions[i].Top += EnemiesMunitionspeed;
                }
                else{
                    EnemiesMuntions[i].Visible = false;
                    int x = rnd.Next(0,10);
                    EnemiesMuntions[i].Location = new Point(enemies[x].Location.X + 20, enemies[x].Location.Y + 30);
                }
                    }
                catch(Exception ex){}
            }
        }



// enemie End -----------------------------------------------------------------------------------------------------------        
  
    





  
    
    }

}
